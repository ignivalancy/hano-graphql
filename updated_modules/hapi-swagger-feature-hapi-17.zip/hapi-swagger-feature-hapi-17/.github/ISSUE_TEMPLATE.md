#### Context

* *hapi-swgger version*:
* *any other relevant information*:

#### What are you trying to achieve or the steps to reproduce ?

Describe your issue here, include example `route` or JOI schemas.

```js
const server.routes({...})
```

#### What result did you get?

#### What did you expect ?